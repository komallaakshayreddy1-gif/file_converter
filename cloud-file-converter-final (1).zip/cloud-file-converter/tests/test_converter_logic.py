import unittest
import io
import os
import sys
import json
import base64
from unittest.mock import MagicMock, patch

# Mock boto3 and botocore before importing lambda modules
mock_boto3 = MagicMock()
mock_dynamodb = MagicMock()
mock_conditions = MagicMock()
mock_key_class = MagicMock()
mock_conditions.Key = mock_key_class

sys.modules['boto3'] = mock_boto3
sys.modules['boto3.dynamodb'] = mock_dynamodb
sys.modules['boto3.dynamodb.conditions'] = mock_conditions
sys.modules['botocore'] = MagicMock()
sys.modules['botocore.exceptions'] = MagicMock()

from botocore.exceptions import ClientError

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
upload_handler_path = os.path.join(BASE_DIR, "lambda", "upload_handler")
file_conv_path = os.path.join(BASE_DIR, "lambda", "file_converter")
conv_status_path = os.path.join(BASE_DIR, "lambda", "conversion_status")
hist_stats_path = os.path.join(BASE_DIR, "lambda", "history_statistics")
down_del_path = os.path.join(BASE_DIR, "lambda", "download_delete")

import importlib.util

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

upload_handler_mod = load_module("upload_handler_mod", os.path.join(upload_handler_path, "lambda_function.py"))
file_converter_mod = load_module("file_converter_mod", os.path.join(file_conv_path, "lambda_function.py"))
conversion_status_mod = load_module("conversion_status_mod", os.path.join(conv_status_path, "lambda_function.py"))
history_stats_mod = load_module("history_stats_mod", os.path.join(hist_stats_path, "lambda_function.py"))
download_delete_mod = load_module("download_delete_mod", os.path.join(down_del_path, "lambda_function.py"))

from PIL import Image

class TestPillowConversions(unittest.TestCase):
    """Test all 6 supported image conversions and edge cases using Pillow."""

    def create_test_image(self, mode="RGBA", size=(80, 60), color=(37, 99, 235, 200), fmt="PNG"):
        buf = io.BytesIO()
        img = Image.new(mode, size, color)
        img.save(buf, format=fmt)
        return buf.getvalue()

    def test_1_png_to_jpg_conversion(self):
        """1. PNG to JPG: Handles RGBA transparency blending onto white background."""
        png_bytes = self.create_test_image(mode="RGBA", size=(80, 60), color=(37, 99, 235, 128), fmt="PNG")
        converted_bytes, content_type = file_converter_mod.convert_image(png_bytes, "JPG")

        self.assertEqual(content_type, "image/jpeg")
        with Image.open(io.BytesIO(converted_bytes)) as out_img:
            self.assertEqual(out_img.format, "JPEG")
            self.assertEqual(out_img.mode, "RGB")
            self.assertEqual(out_img.size, (80, 60))

    def test_2_jpg_to_png_conversion(self):
        """2. JPG to PNG: Converts lossy JPEG to lossless PNG."""
        jpg_bytes = self.create_test_image(mode="RGB", size=(100, 70), color=(30, 58, 138), fmt="JPEG")
        converted_bytes, content_type = file_converter_mod.convert_image(jpg_bytes, "PNG")

        self.assertEqual(content_type, "image/png")
        with Image.open(io.BytesIO(converted_bytes)) as out_img:
            self.assertEqual(out_img.format, "PNG")
            self.assertEqual(out_img.size, (100, 70))

    def test_3_webp_to_jpg_conversion(self):
        """3. WEBP to JPG: Converts WEBP to JPEG preserving visual dimensions."""
        webp_bytes = self.create_test_image(mode="RGB", size=(75, 75), color=(219, 234, 254), fmt="WEBP")
        converted_bytes, content_type = file_converter_mod.convert_image(webp_bytes, "JPG")

        self.assertEqual(content_type, "image/jpeg")
        with Image.open(io.BytesIO(converted_bytes)) as out_img:
            self.assertEqual(out_img.format, "JPEG")
            self.assertEqual(out_img.size, (75, 75))

    def test_4_jpg_to_webp_conversion(self):
        """4. JPG to WEBP: Converts JPEG to high efficiency WEBP."""
        jpg_bytes = self.create_test_image(mode="RGB", size=(90, 90), color=(37, 99, 235), fmt="JPEG")
        converted_bytes, content_type = file_converter_mod.convert_image(jpg_bytes, "WEBP")

        self.assertEqual(content_type, "image/webp")
        with Image.open(io.BytesIO(converted_bytes)) as out_img:
            self.assertEqual(out_img.format, "WEBP")
            self.assertEqual(out_img.size, (90, 90))

    def test_5_png_to_webp_conversion(self):
        """5. PNG to WEBP: Preserves RGBA transparency in WEBP format."""
        png_bytes = self.create_test_image(mode="RGBA", size=(50, 50), color=(30, 58, 138, 180), fmt="PNG")
        converted_bytes, content_type = file_converter_mod.convert_image(png_bytes, "WEBP")

        self.assertEqual(content_type, "image/webp")
        with Image.open(io.BytesIO(converted_bytes)) as out_img:
            self.assertEqual(out_img.format, "WEBP")
            self.assertEqual(out_img.size, (50, 50))

    def test_6_webp_to_png_conversion(self):
        """6. WEBP to PNG: Converts WEBP back to lossless PNG."""
        webp_bytes = self.create_test_image(mode="RGBA", size=(64, 64), color=(25, 99, 235, 255), fmt="WEBP")
        converted_bytes, content_type = file_converter_mod.convert_image(webp_bytes, "PNG")

        self.assertEqual(content_type, "image/png")
        with Image.open(io.BytesIO(converted_bytes)) as out_img:
            self.assertEqual(out_img.format, "PNG")
            self.assertEqual(out_img.size, (64, 64))

    def test_jpeg_alias(self):
        """Verify JPEG target format is recognized as JPG."""
        png_bytes = self.create_test_image(mode="RGB", size=(40, 40), fmt="PNG")
        converted_bytes, content_type = file_converter_mod.convert_image(png_bytes, "JPEG")
        self.assertEqual(content_type, "image/jpeg")

    def test_corrupted_image(self):
        """Verify corrupt byte stream raises ValueError."""
        corrupt_bytes = b"NotARealImageByteStreamHeader123456789"
        with self.assertRaises(ValueError) as ctx:
            file_converter_mod.convert_image(corrupt_bytes, "JPG")
        self.assertIn("valid or recognizable image", str(ctx.exception))

    def test_empty_file_rejection(self):
        """Verify 0-byte input raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            file_converter_mod.convert_image(b"", "JPG")
        self.assertIn("empty (0 byte)", str(ctx.exception))

    def test_unsupported_format_rejection(self):
        """Verify unsupported target format raises ValueError."""
        png_bytes = self.create_test_image(mode="RGB", size=(10, 10), fmt="PNG")
        with self.assertRaises(ValueError) as ctx:
            file_converter_mod.convert_image(png_bytes, "TIFF")
        self.assertIn("Unsupported target format", str(ctx.exception))


class TestUploadHandler(unittest.TestCase):
    """Test validation and presigned URL generation in Lambda 1."""

    def test_sanitize_filename(self):
        """Verify path traversal characters are stripped."""
        unsafe = "../../../etc/passwd/test_image.png"
        safe = upload_handler_mod.sanitize_filename(unsafe)
        self.assertNotIn("/", safe)
        self.assertNotIn("\\", safe)
        self.assertTrue(safe.endswith(".png"))

    def test_identical_source_and_target_rejection(self):
        """Reject when output_format matches source format."""
        event = {
            "httpMethod": "POST",
            "body": json.dumps({"filename": "image.png", "file_size": 50000, "output_format": "PNG"})
        }
        resp = upload_handler_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 400)
        self.assertIn("identical", resp["body"])

    def test_oversized_file_rejection(self):
        """Reject file exceeding 10 MB limit."""
        event = {
            "httpMethod": "POST",
            "body": json.dumps({"filename": "huge.jpg", "file_size": 25 * 1024 * 1024, "output_format": "PNG"})
        }
        resp = upload_handler_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 400)
        self.assertIn("exceeds the maximum allowed limit", resp["body"])

    def test_unsupported_extension_rejection(self):
        """Reject non-image extensions."""
        event = {
            "httpMethod": "POST",
            "body": json.dumps({"filename": "malware.exe", "file_size": 1000, "output_format": "JPG"})
        }
        resp = upload_handler_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 400)
        self.assertIn("Unsupported input format", resp["body"])

    def test_valid_request(self):
        """Valid request returns 200 with conversion_id and presigned URL."""
        upload_handler_mod.s3_client.generate_presigned_url.return_value = "https://s3.amazonaws.com/test-bucket/put-url"
        event = {
            "httpMethod": "POST",
            "body": json.dumps({"filename": "vacation.png", "file_size": 1048576, "output_format": "JPG"})
        }
        resp = upload_handler_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 200)
        data = json.loads(resp["body"])
        self.assertIn("conversion_id", data)
        self.assertIn("upload_url", data)


class TestFileConverterSecurity(unittest.TestCase):
    """Test security guards in file_converter Lambda 2."""

    def test_non_uploads_prefix_ignored(self):
        """Verify keys outside uploads/ are skipped to prevent recursion."""
        event = {
            "Records": [{
                "eventSource": "aws:s3",
                "s3": {
                    "bucket": {"name": "test-bucket"},
                    "object": {"key": "converted/123-456/output.jpg"}
                }
            }]
        }
        resp = file_converter_mod.lambda_handler(event, None)
        self.assertEqual(resp["status"], "finished")
        self.assertEqual(len(resp["results"]), 0)

    def test_duplicate_completed_event_skipped(self):
        """Verify already COMPLETED conversions are skipped."""
        cid = "11111111-2222-3333-4444-555555555555"
        file_converter_mod.table.get_item.return_value = {
            "Item": {
                "conversion_id": cid,
                "status": "COMPLETED",
                "output_format": "JPG"
            }
        }
        event = {
            "Records": [{
                "eventSource": "aws:s3",
                "s3": {
                    "bucket": {"name": "test-bucket"},
                    "object": {"key": f"uploads/{cid}/photo.png"}
                }
            }]
        }
        resp = file_converter_mod.lambda_handler(event, None)
        self.assertEqual(resp["results"][0]["status"], "already_completed")

    def test_empty_s3_file_fails_safely(self):
        """Verify empty (0 byte) S3 object marks status FAILED."""
        cid = "22222222-3333-4444-5555-666666666666"
        file_converter_mod.table.get_item.return_value = {
            "Item": {
                "conversion_id": cid,
                "status": "PENDING",
                "output_format": "JPG"
            }
        }
        file_converter_mod.s3_client.head_object.return_value = {"ContentLength": 0}

        event = {
            "Records": [{
                "eventSource": "aws:s3",
                "s3": {
                    "bucket": {"name": "test-bucket"},
                    "object": {"key": f"uploads/{cid}/empty.png"}
                }
            }]
        }
        resp = file_converter_mod.lambda_handler(event, None)
        self.assertEqual(resp["results"][0]["status"], "FAILED")
        self.assertIn("empty", resp["results"][0]["error"])


class TestConversionStatusAndHistory(unittest.TestCase):
    """Test Lambda 3 (conversion_status) and Lambda 4 (history_statistics)."""

    def test_status_invalid_uuid(self):
        """Reject non-UUID format."""
        event = {"pathParameters": {"id": "invalid;DROP TABLE;"}}
        resp = conversion_status_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 400)

    def test_status_not_found(self):
        """Return 404 if item does not exist."""
        cid = "33333333-4444-5555-6666-777777777777"
        conversion_status_mod.table.get_item.return_value = {}
        event = {"pathParameters": {"id": cid}}
        resp = conversion_status_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 404)

    def test_history_pagination_token_roundtrip(self):
        """Verify LastEvaluatedKey encodes and decodes accurately."""
        orig_key = {"conversion_id": "test-id-123", "created_at": "2026-11-07T12:00:00Z"}
        token = history_stats_mod.encode_next_token(orig_key)
        self.assertIsNotNone(token)
        decoded = history_stats_mod.decode_next_token(token)
        self.assertEqual(decoded["conversion_id"], "test-id-123")

    def test_statistics_aggregation(self):
        """Verify statistics correctly accumulates status counts and format breakdown."""
        history_stats_mod.table.scan.return_value = {
            "Items": [
                {"conversion_id": "1", "status": "COMPLETED", "original_size": 100, "converted_size": 80, "original_format": "PNG", "output_format": "JPG"},
                {"conversion_id": "2", "status": "COMPLETED", "original_size": 200, "converted_size": 150, "original_format": "PNG", "output_format": "JPG"},
                {"conversion_id": "3", "status": "FAILED", "original_size": 50, "converted_size": 0, "original_format": "JPG", "output_format": "PNG"},
                {"conversion_id": "4", "status": "PROCESSING", "original_size": 300, "converted_size": 0, "original_format": "WEBP", "output_format": "PNG"},
            ]
        }
        resp = history_stats_mod.get_statistics()
        self.assertEqual(resp["statusCode"], 200)
        data = json.loads(resp["body"])
        self.assertEqual(data["total_files_uploaded"], 4)
        self.assertEqual(data["total_conversions_completed"], 2)
        self.assertEqual(data["total_failed_conversions"], 1)
        self.assertEqual(data["total_files_processing"], 1)
        self.assertEqual(data["total_original_storage_bytes"], 650)
        self.assertEqual(data["total_converted_storage_bytes"], 230)
        self.assertEqual(data["format_statistics"]["PNG_TO_JPG"], 2)


class TestDownloadDeleteSecurity(unittest.TestCase):
    """Test Lambda 5 (download_delete) path isolation and permissions."""

    def test_download_incomplete_job_rejected(self):
        """Reject download request if conversion status is not COMPLETED."""
        cid = "44444444-5555-6666-7777-888888888888"
        download_delete_mod.table.get_item.return_value = {
            "Item": {"conversion_id": cid, "status": "PROCESSING"}
        }
        event = {"rawPath": f"/download/{cid}", "pathParameters": {"id": cid}, "httpMethod": "GET"}
        resp = download_delete_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 400)
        self.assertIn("not yet completed", resp["body"])

    def test_download_foreign_key_forbidden(self):
        """Reject download if converted_s3_key tries to access foreign prefix."""
        cid = "55555555-6666-7777-8888-999999999999"
        download_delete_mod.table.get_item.return_value = {
            "Item": {
                "conversion_id": cid,
                "status": "COMPLETED",
                "converted_s3_key": "private/secret_keys.json"
            }
        }
        event = {"rawPath": f"/download/{cid}", "pathParameters": {"id": cid}, "httpMethod": "GET"}
        resp = download_delete_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 403)

    def test_delete_isolated_to_conversion_prefix(self):
        """Ensure deletion is strictly scoped to this conversion's prefix."""
        cid = "66666666-7777-8888-9999-000000000000"
        download_delete_mod.table.get_item.return_value = {
            "Item": {
                "conversion_id": cid,
                "original_s3_key": f"uploads/{cid}/input.png",
                "converted_s3_key": f"converted/{cid}/output.jpg"
            }
        }
        event = {"rawPath": f"/conversion/{cid}", "pathParameters": {"id": cid}, "httpMethod": "DELETE"}
        resp = download_delete_mod.lambda_handler(event, None)
        self.assertEqual(resp["statusCode"], 200)
        download_delete_mod.s3_client.delete_object.assert_any_call(
            Bucket=download_delete_mod.BUCKET_NAME, Key=f"uploads/{cid}/input.png"
        )
        download_delete_mod.s3_client.delete_object.assert_any_call(
            Bucket=download_delete_mod.BUCKET_NAME, Key=f"converted/{cid}/output.jpg"
        )


if __name__ == "__main__":
    unittest.main()
