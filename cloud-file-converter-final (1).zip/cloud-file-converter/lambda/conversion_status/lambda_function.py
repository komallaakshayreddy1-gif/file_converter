import json
import os
import re
import decimal
import logging
import boto3
from botocore.exceptions import ClientError

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configuration from Environment Variables with secure defaults
TABLE_NAME = os.environ.get("TABLE_NAME", "FileConversions")
ALLOWED_ORIGIN = os.environ.get("ALLOWED_ORIGIN", "*")

# UUID validation pattern for conversion IDs
UUID_REGEX = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

class DecimalEncoder(json.JSONEncoder):
    """Helper class to convert DynamoDB Decimal types to standard Python int/float."""
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 == 0:
                return int(o)
            return float(o)
        return super(DecimalEncoder, self).default(o)

def get_cors_headers():
    return {
        "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "GET,OPTIONS",
        "Content-Type": "application/json"
    }

def build_response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": get_cors_headers(),
        "body": json.dumps(body, cls=DecimalEncoder)
    }

def lambda_handler(event, context):
    """
    Handles GET /conversion/{id} to query status of a conversion request.
    Validates conversion ID, fetches DynamoDB record, and returns clean metadata.
    """
    http_method = event.get("httpMethod") or event.get("requestContext", {}).get("http", {}).get("method")
    if http_method == "OPTIONS":
        return build_response(200, {"message": "OK"})

    # Extract conversion_id from path parameters or raw path
    path_parameters = event.get("pathParameters") or {}
    conversion_id = path_parameters.get("id")

    if not conversion_id:
        raw_path = event.get("rawPath") or event.get("path", "")
        path_parts = [p for p in raw_path.strip("/").split("/") if p]
        if len(path_parts) >= 2 and path_parts[0] == "conversion":
            conversion_id = path_parts[1]

    if not conversion_id:
        return build_response(400, {"error": "Conversion ID parameter is required in URL path: /conversion/{id}"})

    conversion_id = str(conversion_id).strip()

    # Validate conversion ID format to prevent invalid queries
    if not UUID_REGEX.match(conversion_id):
        return build_response(400, {"error": "Invalid conversion ID format. A valid UUID is required."})

    try:
        response = table.get_item(Key={"conversion_id": conversion_id})
        item = response.get("Item")

        if not item:
            return build_response(404, {
                "error": f"Conversion job '{conversion_id}' not found.",
                "conversion_id": conversion_id
            })

        result = {
            "conversion_id": item.get("conversion_id"),
            "original_filename": item.get("original_filename"),
            "original_format": item.get("original_format"),
            "output_format": item.get("output_format"),
            "original_size": item.get("original_size"),
            "converted_size": item.get("converted_size"),
            "status": item.get("status"),
            "created_at": item.get("created_at"),
            "completed_at": item.get("completed_at"),
            "conversion_time_ms": item.get("conversion_time_ms"),
            "error_message": item.get("error_message")
        }

        return build_response(200, result)

    except ClientError as e:
        logger.exception(f"ClientError querying DynamoDB for {conversion_id}")
        return build_response(500, {
            "error": "Failed to retrieve conversion record from database."
        })
    except Exception as e:
        logger.exception(f"Unexpected error in conversion_status handler for {conversion_id}")
        return build_response(500, {
            "error": "Internal server error occurred while retrieving conversion status."
        })
