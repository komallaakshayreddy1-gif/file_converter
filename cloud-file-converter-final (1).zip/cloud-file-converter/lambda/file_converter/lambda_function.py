import json
import os
import io
import time
import re
import urllib.parse
import datetime
import logging
import boto3
from botocore.exceptions import ClientError
from PIL import Image, UnidentifiedImageError

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configuration from Environment Variables with secure defaults
BUCKET_NAME = os.environ.get("BUCKET_NAME", "cloud-file-converter-storage")
TABLE_NAME = os.environ.get("TABLE_NAME", "FileConversions")
MAX_FILE_SIZE_BYTES = int(os.environ.get("MAX_FILE_SIZE_BYTES", str(10 * 1024 * 1024)))  # 10 MB limit

ALLOWED_INPUT_FORMATS = {"PNG", "JPEG", "JPG", "WEBP"}

MIME_TYPES = {
    "JPG": "image/jpeg",
    "JPEG": "image/jpeg",
    "PNG": "image/png",
    "WEBP": "image/webp"
}

# UUID validation pattern for conversion IDs
UUID_REGEX = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

def convert_image(input_bytes, target_format):
    """
    Validates actual image content and converts it to the requested format using Pillow.
    Handles transparency, RGBA color channels, and format-specific optimizations.
    """
    target_fmt = target_format.upper()
    if target_fmt == "JPEG":
        target_fmt = "JPG"

    if len(input_bytes) == 0:
        raise ValueError("Cannot convert an empty (0 byte) file.")

    try:
        input_buffer = io.BytesIO(input_bytes)
        with Image.open(input_buffer) as img:
            # Check actual image format detected by Pillow
            detected_format = (img.format or "").upper()
            logger.info(f"Detected image format: {detected_format}, mode: {img.mode}, dimensions: {img.size}")

            if detected_format not in ALLOWED_INPUT_FORMATS:
                raise ValueError(
                    f"Unsupported image content: detected format is '{detected_format}'. "
                    f"Only PNG, JPEG, and WEBP images are supported."
                )

            # Prevent decompression bomb attacks
            if img.size[0] * img.size[1] > 50_000_000:
                raise ValueError("Image dimensions exceed the allowable processing limit (max 50 megapixels).")

            # Force load image pixels to detect truncated or corrupted files
            img.load()

            output_buffer = io.BytesIO()

            if target_fmt == "JPG":
                # JPEG does not support transparency or alpha channel
                if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
                    # Blend onto a pure white background
                    rgba_img = img.convert("RGBA")
                    background = Image.new("RGB", rgba_img.size, (255, 255, 255))
                    alpha_channel = rgba_img.split()[3]
                    background.paste(rgba_img, mask=alpha_channel)
                    final_img = background
                elif img.mode != "RGB":
                    final_img = img.convert("RGB")
                else:
                    final_img = img

                final_img.save(output_buffer, format="JPEG", quality=90, optimize=True)
                content_type = "image/jpeg"

            elif target_fmt == "PNG":
                # PNG supports RGBA, RGB, P, L
                final_img = img
                final_img.save(output_buffer, format="PNG", optimize=True)
                content_type = "image/png"

            elif target_fmt == "WEBP":
                # WEBP supports both RGB and RGBA
                if img.mode not in ("RGB", "RGBA"):
                    if "transparency" in img.info or img.mode in ("LA", "PA"):
                        final_img = img.convert("RGBA")
                    else:
                        final_img = img.convert("RGB")
                else:
                    final_img = img

                final_img.save(output_buffer, format="WEBP", quality=90, method=4)
                content_type = "image/webp"

            else:
                raise ValueError(f"Unsupported target format: '{target_fmt}'. Supported: JPG, PNG, WEBP.")

            output_bytes = output_buffer.getvalue()
            return output_bytes, content_type

    except UnidentifiedImageError as e:
        raise ValueError("The uploaded file is not a valid or recognizable image.") from e
    except Image.DecompressionBombError as e:
        raise ValueError("Image size exceeds maximum decompression threshold.") from e
    except ValueError:
        raise
    except Exception as e:
        raise RuntimeError(f"Image processing failed: {str(e)}") from e

def mark_failed(conversion_id, error_message):
    """Marks the DynamoDB record as FAILED with an error message."""
    try:
        completed_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        table.update_item(
            Key={"conversion_id": conversion_id},
            UpdateExpression="SET #st = :status, error_message = :err, completed_at = :completed_at",
            ExpressionAttributeNames={"#st": "status"},
            ExpressionAttributeValues={
                ":status": "FAILED",
                ":err": error_message[:1000],  # truncate long errors for safety
                ":completed_at": completed_at
            }
        )
        logger.info(f"Marked conversion {conversion_id} as FAILED: {error_message}")
    except Exception as e:
        logger.error(f"Failed to update DynamoDB status to FAILED for {conversion_id}: {str(e)}")

def lambda_handler(event, context):
    """
    Triggered by S3 ObjectCreated events on the uploads/ prefix.
    Validates actual object size, downloads and converts the image using Pillow,
    saves the output to converted/, and updates DynamoDB.
    """
    logger.info("Received S3 Event: %s", json.dumps(event))

    records = event.get("Records", [])
    if not records:
        logger.warning("No records found in event.")
        return {"status": "ignored", "reason": "No records in event"}

    results = []

    for record in records:
        # Verify event source
        if record.get("eventSource") != "aws:s3" and "s3" not in record:
            logger.warning("Record is not an S3 event, skipping.")
            continue

        s3_info = record.get("s3", {})
        bucket = s3_info.get("bucket", {}).get("name", BUCKET_NAME)
        raw_key = s3_info.get("object", {}).get("key", "")
        key = urllib.parse.unquote_plus(raw_key)

        logger.info(f"Processing object: Bucket={bucket}, Key={key}")

        # CRITICAL RECURSION GUARD: ONLY process keys starting with 'uploads/'
        if not key.startswith("uploads/"):
            logger.warning(f"Key '{key}' does not start with 'uploads/'. Skipping to prevent infinite loop.")
            continue

        # Expected key structure: uploads/<conversion_id>/<filename>
        parts = key.split("/")
        if len(parts) < 3:
            logger.error(f"Invalid key structure: '{key}'. Expected uploads/<conversion_id>/<filename>")
            continue

        conversion_id = parts[1]
        filename = "/".join(parts[2:])

        # Validate conversion_id format (prevent path traversal or injection)
        if not UUID_REGEX.match(conversion_id):
            logger.error(f"Invalid conversion_id format: '{conversion_id}'. Skipping.")
            continue

        start_time = time.time()

        # Step 1: Retrieve conversion metadata from DynamoDB
        item = None
        for attempt in range(3):
            try:
                db_response = table.get_item(Key={"conversion_id": conversion_id})
                item = db_response.get("Item")
                if item:
                    break
                time.sleep(1)  # small backoff if DynamoDB put is slightly behind S3 event
            except ClientError as e:
                logger.error(f"Error accessing DynamoDB for {conversion_id}: {str(e)}")
                break

        if not item:
            logger.error(f"No DynamoDB record found for conversion_id: {conversion_id}")
            continue

        current_status = item.get("status")

        # Duplicate event protection: Do not re-process completed records
        if current_status == "COMPLETED":
            logger.info(f"Conversion {conversion_id} already marked COMPLETED. Skipping duplicate event.")
            results.append({"conversion_id": conversion_id, "status": "already_completed"})
            continue

        # If already processing within the last 90 seconds, avoid duplicate concurrent conversion
        if current_status == "PROCESSING":
            started_at_str = item.get("processing_started_at")
            if started_at_str:
                try:
                    started_dt = datetime.datetime.fromisoformat(started_at_str.replace("Z", "+00:00"))
                    elapsed_secs = (datetime.datetime.now(datetime.timezone.utc) - started_dt).total_seconds()
                    if elapsed_secs < 90:
                        logger.info(f"Conversion {conversion_id} currently PROCESSING (elapsed {elapsed_secs:.1f}s). Skipping duplicate.")
                        results.append({"conversion_id": conversion_id, "status": "already_processing"})
                        continue
                except Exception:
                    pass

        output_format = item.get("output_format", "JPG")
        converted_s3_key = item.get("converted_s3_key")

        # Fallback if converted_s3_key was not set in DB
        if not converted_s3_key:
            base_name = filename.rsplit(".", 1)[0]
            ext = "jpg" if output_format.upper() in ("JPG", "JPEG") else output_format.lower()
            converted_s3_key = f"converted/{conversion_id}/{base_name}.{ext}"

        # Update status to PROCESSING
        try:
            table.update_item(
                Key={"conversion_id": conversion_id},
                UpdateExpression="SET #st = :status, processing_started_at = :now",
                ExpressionAttributeNames={"#st": "status"},
                ExpressionAttributeValues={
                    ":status": "PROCESSING",
                    ":now": datetime.datetime.now(datetime.timezone.utc).isoformat()
                }
            )
        except ClientError as e:
            logger.error(f"Failed to update status to PROCESSING for {conversion_id}: {str(e)}")

        # Step 2: Validate actual S3 object size via head_object BEFORE downloading
        try:
            head_resp = s3_client.head_object(Bucket=bucket, Key=key)
            actual_size = head_resp.get("ContentLength", 0)

            logger.info(f"S3 Object size verified: {actual_size} bytes")

            if actual_size == 0:
                err_msg = "The uploaded file is empty (0 bytes)."
                mark_failed(conversion_id, err_msg)
                results.append({"conversion_id": conversion_id, "status": "FAILED", "error": err_msg})
                continue

            if actual_size > MAX_FILE_SIZE_BYTES:
                max_mb = MAX_FILE_SIZE_BYTES / (1024 * 1024)
                err_msg = f"Uploaded file size ({actual_size} bytes) exceeds maximum allowable limit of {max_mb:.0f} MB."
                mark_failed(conversion_id, err_msg)
                results.append({"conversion_id": conversion_id, "status": "FAILED", "error": err_msg})
                continue

        except ClientError as e:
            err_msg = f"Failed to inspect uploaded file in S3: {e.response.get('Error', {}).get('Message', str(e))}"
            logger.error(err_msg)
            mark_failed(conversion_id, err_msg)
            results.append({"conversion_id": conversion_id, "status": "FAILED", "error": err_msg})
            continue

        # Step 3: Download original file content from S3
        try:
            logger.info(f"Downloading object from S3: {bucket}/{key}")
            s3_obj = s3_client.get_object(Bucket=bucket, Key=key)
            input_bytes = s3_obj["Body"].read()
        except ClientError as e:
            err_msg = f"Failed to download original file from S3: {e.response.get('Error', {}).get('Message', str(e))}"
            logger.error(err_msg)
            mark_failed(conversion_id, err_msg)
            results.append({"conversion_id": conversion_id, "status": "FAILED", "error": err_msg})
            continue

        # Step 4: Perform conversion using Pillow
        try:
            logger.info(f"Starting image conversion for {conversion_id} to format {output_format}")
            converted_bytes, content_type = convert_image(input_bytes, output_format)
            converted_size = len(converted_bytes)
            conversion_time_ms = int((time.time() - start_time) * 1000)

            logger.info(f"Conversion successful in {conversion_time_ms} ms. Output size: {converted_size} bytes.")

            # Step 5: Upload converted image to converted/ prefix
            logger.info(f"Uploading converted file to S3: {bucket}/{converted_s3_key}")
            s3_client.put_object(
                Bucket=bucket,
                Key=converted_s3_key,
                Body=converted_bytes,
                ContentType=content_type,
                Metadata={
                    "conversion_id": conversion_id,
                    "original_filename": item.get("original_filename", filename),
                    "output_format": output_format
                }
            )

            # Step 6: Update DynamoDB with COMPLETED status and metrics
            completed_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
            table.update_item(
                Key={"conversion_id": conversion_id},
                UpdateExpression="""SET #st = :status,
                                       original_size = :orig_size,
                                       converted_s3_key = :converted_key,
                                       converted_size = :converted_size,
                                       conversion_time_ms = :time_ms,
                                       completed_at = :completed_at,
                                       error_message = :err""",
                ExpressionAttributeNames={"#st": "status"},
                ExpressionAttributeValues={
                    ":status": "COMPLETED",
                    ":orig_size": actual_size,
                    ":converted_key": converted_s3_key,
                    ":converted_size": converted_size,
                    ":time_ms": conversion_time_ms,
                    ":completed_at": completed_at,
                    ":err": None
                }
            )

            results.append({
                "conversion_id": conversion_id,
                "status": "COMPLETED",
                "time_ms": conversion_time_ms,
                "converted_size": converted_size
            })

        except Exception as e:
            err_msg = str(e)
            logger.exception(f"Conversion failed for {conversion_id}: {err_msg}")
            mark_failed(conversion_id, err_msg)
            results.append({"conversion_id": conversion_id, "status": "FAILED", "error": err_msg})

    return {"status": "finished", "results": results}
