import json
import os
import re
import uuid
import datetime
import logging
import boto3
from botocore.exceptions import ClientError

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configuration from Environment Variables with secure defaults
BUCKET_NAME = os.environ.get("BUCKET_NAME", "cloud-file-converter-storage")
TABLE_NAME = os.environ.get("TABLE_NAME", "FileConversions")
MAX_FILE_SIZE_BYTES = int(os.environ.get("MAX_FILE_SIZE_BYTES", str(10 * 1024 * 1024)))  # 10 MB default
URL_EXPIRATION_SECONDS = int(os.environ.get("URL_EXPIRATION_SECONDS", "300"))  # 5 minutes
ALLOWED_ORIGIN = os.environ.get("ALLOWED_ORIGIN", "*")

SUPPORTED_INPUT_FORMATS = {
    "png": "image/png",
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "webp": "image/webp"
}

SUPPORTED_OUTPUT_FORMATS = {
    "JPG": {"ext": "jpg", "mime": "image/jpeg"},
    "JPEG": {"ext": "jpg", "mime": "image/jpeg"},
    "PNG": {"ext": "png", "mime": "image/png"},
    "WEBP": {"ext": "webp", "mime": "image/webp"}
}

ALLOWED_CONVERSIONS = {
    ("PNG", "JPG"),
    ("PNG", "JPEG"),
    ("PNG", "WEBP"),
    ("JPG", "PNG"),
    ("JPEG", "PNG"),
    ("JPG", "WEBP"),
    ("JPEG", "WEBP"),
    ("WEBP", "JPG"),
    ("WEBP", "JPEG"),
    ("WEBP", "PNG")
}

s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

def get_cors_headers():
    return {
        "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
        "Content-Type": "application/json"
    }

def build_response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": get_cors_headers(),
        "body": json.dumps(body)
    }

def sanitize_filename(filename):
    """Sanitize filename to prevent directory traversal and remove unsafe characters."""
    if not filename:
        return "upload_file"
    # Take basename only to strip any directory traversal
    filename = os.path.basename(filename)
    # Replace any character that is not alphanumeric, dot, underscore, or hyphen
    filename = re.sub(r'[^a-zA-Z0-9._-]', '_', filename)
    # Trim excessive length
    if len(filename) > 128:
        base, ext = os.path.splitext(filename)
        filename = base[:120] + ext
    return filename or "upload_file"

def lambda_handler(event, context):
    """
    Handles POST /upload-url request to generate a presigned S3 upload URL.
    Validates input parameters, registers a PENDING job in DynamoDB, and returns presigned PUT URL.
    """
    # Handle CORS preflight OPTIONS
    http_method = event.get("httpMethod") or event.get("requestContext", {}).get("http", {}).get("method")
    if http_method == "OPTIONS":
        return build_response(200, {"message": "OK"})

    try:
        body_raw = event.get("body")
        if not body_raw:
            return build_response(400, {"error": "Missing request body."})

        if isinstance(body_raw, str):
            try:
                body = json.loads(body_raw)
            except json.JSONDecodeError:
                return build_response(400, {"error": "Invalid JSON format in request body."})
        elif isinstance(body_raw, dict):
            body = body_raw
        else:
            return build_response(400, {"error": "Invalid request body type."})

        raw_filename = str(body.get("filename", "")).strip()
        file_size = body.get("file_size")
        output_format_raw = str(body.get("output_format", "")).strip().upper()

        # Validate filename
        if not raw_filename:
            return build_response(400, {"error": "Filename is required."})

        safe_filename = sanitize_filename(raw_filename)
        name_parts = safe_filename.rsplit(".", 1)
        if len(name_parts) < 2 or not name_parts[1]:
            return build_response(400, {"error": "Filename must have a valid extension (.png, .jpg, .jpeg, .webp)."})

        file_extension = name_parts[1].lower()
        base_name = name_parts[0]

        # Validate input format
        if file_extension not in SUPPORTED_INPUT_FORMATS:
            return build_response(400, {
                "error": f"Unsupported input format: '.{file_extension}'. Supported formats are: png, jpg, jpeg, webp."
            })

        input_format_normalized = "JPG" if file_extension in ("jpg", "jpeg") else file_extension.upper()
        content_type = SUPPORTED_INPUT_FORMATS[file_extension]

        # Validate output format
        if not output_format_raw:
            return build_response(400, {"error": "output_format parameter is required."})

        if output_format_raw not in SUPPORTED_OUTPUT_FORMATS:
            return build_response(400, {
                "error": f"Unsupported output format: '{output_format_raw}'. Supported formats are: JPG, PNG, WEBP."
            })

        normalized_output = "JPG" if output_format_raw in ("JPG", "JPEG") else output_format_raw

        # Validate conversion pair
        if input_format_normalized == normalized_output:
            return build_response(400, {
                "error": f"Source format '{input_format_normalized}' and target format '{normalized_output}' are identical. Please select a different target format."
            })

        if (input_format_normalized, normalized_output) not in ALLOWED_CONVERSIONS:
            return build_response(400, {
                "error": f"Conversion from {input_format_normalized} to {normalized_output} is not supported."
            })

        # Validate file size
        if file_size is None or not isinstance(file_size, (int, float)) or file_size <= 0:
            return build_response(400, {"error": "A valid positive file_size in bytes is required."})

        if file_size > MAX_FILE_SIZE_BYTES:
            max_mb = MAX_FILE_SIZE_BYTES / (1024 * 1024)
            return build_response(400, {
                "error": f"File size exceeds the maximum allowed limit of {max_mb:.0f} MB."
            })

        # Generate cryptographically secure UUID for conversion ID
        conversion_id = str(uuid.uuid4())
        created_at = datetime.datetime.now(datetime.timezone.utc).isoformat()

        # Construct S3 keys
        original_s3_key = f"uploads/{conversion_id}/{safe_filename}"
        target_ext = SUPPORTED_OUTPUT_FORMATS[normalized_output]["ext"]
        converted_filename = f"{base_name}.{target_ext}"
        converted_s3_key = f"converted/{conversion_id}/{converted_filename}"

        # Register DynamoDB record in PENDING status
        # Note: job_type="CONVERSION" enables the GSI CreatedAtIndex for high-performance sorting & pagination
        item = {
            "conversion_id": conversion_id,
            "job_type": "CONVERSION",
            "original_filename": safe_filename,
            "original_format": input_format_normalized,
            "output_format": normalized_output,
            "original_s3_key": original_s3_key,
            "converted_s3_key": converted_s3_key,
            "original_size": int(file_size),
            "converted_size": 0,
            "status": "PENDING",
            "created_at": created_at,
            "completed_at": None,
            "conversion_time_ms": None,
            "error_message": None
        }

        table.put_item(Item=item)
        logger.info(f"Created PENDING conversion record {conversion_id} for file {safe_filename}")

        # Generate Presigned S3 PUT URL
        presigned_url = s3_client.generate_presigned_url(
            ClientMethod="put_object",
            Params={
                "Bucket": BUCKET_NAME,
                "Key": original_s3_key,
                "ContentType": content_type
            },
            ExpiresIn=URL_EXPIRATION_SECONDS
        )

        return build_response(200, {
            "message": "Upload authorization generated successfully.",
            "conversion_id": conversion_id,
            "upload_url": presigned_url,
            "s3_key": original_s3_key,
            "required_headers": {
                "Content-Type": content_type
            },
            "expires_in_seconds": URL_EXPIRATION_SECONDS
        })

    except ClientError as e:
        logger.exception("AWS ClientError in upload_handler")
        return build_response(500, {
            "error": "Cloud storage service error while generating upload URL.",
            "details": e.response.get("Error", {}).get("Message", "Operation failed.")
        })
    except Exception as e:
        logger.exception("Unexpected exception in upload_handler")
        return build_response(500, {
            "error": "Internal server error occurred while processing your request."
        })
