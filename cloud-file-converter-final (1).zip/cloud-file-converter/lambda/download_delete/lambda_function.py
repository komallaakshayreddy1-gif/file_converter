import json
import os
import re
import logging
import boto3
from botocore.exceptions import ClientError

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configuration from Environment Variables with secure defaults
BUCKET_NAME = os.environ.get("BUCKET_NAME", "cloud-file-converter-storage")
TABLE_NAME = os.environ.get("TABLE_NAME", "FileConversions")
DOWNLOAD_EXPIRATION_SECONDS = int(os.environ.get("DOWNLOAD_EXPIRATION_SECONDS", "300"))  # 5 minutes
ALLOWED_ORIGIN = os.environ.get("ALLOWED_ORIGIN", "*")

# UUID validation pattern for conversion IDs
UUID_REGEX = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

def get_cors_headers():
    return {
        "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "GET,DELETE,OPTIONS",
        "Content-Type": "application/json"
    }

def build_response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": get_cors_headers(),
        "body": json.dumps(body)
    }

def handle_download(conversion_id):
    """
    Generates a presigned download URL for the converted file if status is COMPLETED.
    Enforces strict path isolation to prevent unauthorized object access.
    """
    try:
        response = table.get_item(Key={"conversion_id": conversion_id})
        item = response.get("Item")

        if not item:
            return build_response(404, {"error": f"Conversion record '{conversion_id}' not found."})

        status = item.get("status")
        if status != "COMPLETED":
            return build_response(400, {
                "error": f"File conversion is not yet completed. Current status: '{status}'.",
                "status": status,
                "conversion_id": conversion_id
            })

        converted_s3_key = item.get("converted_s3_key")
        if not converted_s3_key:
            return build_response(404, {"error": "Converted file key is missing from record."})

        # Security check: Ensure key strictly belongs to this conversion's isolated directory
        expected_prefix = f"converted/{conversion_id}/"
        if not converted_s3_key.startswith(expected_prefix):
            logger.error(f"Security Alert: converted_s3_key '{converted_s3_key}' does not match prefix '{expected_prefix}'")
            return build_response(403, {"error": "Access to the requested file key is unauthorized."})

        # Check that file actually exists in S3 before generating URL
        try:
            s3_client.head_object(Bucket=BUCKET_NAME, Key=converted_s3_key)
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") in ("404", "NoSuchKey"):
                return build_response(404, {"error": "Converted file was not found in storage."})
            logger.warning(f"head_object failed for key {converted_s3_key}: {str(e)}")

        # Determine download filename
        original_filename = item.get("original_filename", "converted_file")
        output_format = item.get("output_format", "JPG").lower()
        base_name = original_filename.rsplit(".", 1)[0]
        ext = "jpg" if output_format in ("jpg", "jpeg") else output_format
        download_filename = f"{base_name}.{ext}"

        # Generate presigned download URL with Content-Disposition header
        presigned_url = s3_client.generate_presigned_url(
            ClientMethod="get_object",
            Params={
                "Bucket": BUCKET_NAME,
                "Key": converted_s3_key,
                "ResponseContentDisposition": f'attachment; filename="{download_filename}"'
            },
            ExpiresIn=DOWNLOAD_EXPIRATION_SECONDS
        )

        return build_response(200, {
            "conversion_id": conversion_id,
            "download_url": presigned_url,
            "filename": download_filename,
            "expires_in_seconds": DOWNLOAD_EXPIRATION_SECONDS
        })

    except ClientError as e:
        logger.exception("AWS ClientError in handle_download")
        return build_response(500, {
            "error": "Error generating download link."
        })

def handle_delete(conversion_id):
    """
    Deletes both original and converted files from S3 and removes the DynamoDB record.
    Enforces strict path isolation to prevent unauthorized object deletion.
    """
    try:
        response = table.get_item(Key={"conversion_id": conversion_id})
        item = response.get("Item")

        if not item:
            return build_response(404, {"error": f"Conversion record '{conversion_id}' not found."})

        original_s3_key = item.get("original_s3_key")
        converted_s3_key = item.get("converted_s3_key")

        # Security check: Ensure keys strictly belong to this conversion's isolated directories
        expected_upload_prefix = f"uploads/{conversion_id}/"
        expected_conv_prefix = f"converted/{conversion_id}/"

        # Delete original object if exists and prefix matches
        if original_s3_key and original_s3_key.startswith(expected_upload_prefix):
            try:
                s3_client.delete_object(Bucket=BUCKET_NAME, Key=original_s3_key)
                logger.info(f"Deleted original file {original_s3_key}")
            except ClientError as e:
                logger.warning(f"Failed to delete original S3 key {original_s3_key}: {str(e)}")

        # Delete converted object if exists and prefix matches
        if converted_s3_key and converted_s3_key.startswith(expected_conv_prefix):
            try:
                s3_client.delete_object(Bucket=BUCKET_NAME, Key=converted_s3_key)
                logger.info(f"Deleted converted file {converted_s3_key}")
            except ClientError as e:
                logger.warning(f"Failed to delete converted S3 key {converted_s3_key}: {str(e)}")

        # Delete DynamoDB record
        table.delete_item(Key={"conversion_id": conversion_id})
        logger.info(f"Deleted DynamoDB record for {conversion_id}")

        return build_response(200, {
            "message": "Conversion record and associated files were deleted successfully.",
            "conversion_id": conversion_id
        })

    except ClientError as e:
        logger.exception("AWS ClientError in handle_delete")
        return build_response(500, {
            "error": "Error deleting conversion resources."
        })

def lambda_handler(event, context):
    """
    Routes GET /download/{id} and DELETE /conversion/{id}.
    """
    http_method = (event.get("httpMethod") or event.get("requestContext", {}).get("http", {}).get("method") or "GET").upper()

    if http_method == "OPTIONS":
        return build_response(200, {"message": "OK"})

    path_parameters = event.get("pathParameters") or {}
    conversion_id = path_parameters.get("id")

    if not conversion_id:
        raw_path = event.get("rawPath") or event.get("path", "")
        parts = [p for p in raw_path.strip("/").split("/") if p]
        if len(parts) >= 2:
            conversion_id = parts[1]

    if not conversion_id:
        return build_response(400, {"error": "Missing conversion ID parameter in request URL."})

    conversion_id = str(conversion_id).strip()

    # Validate conversion ID format
    if not UUID_REGEX.match(conversion_id):
        return build_response(400, {"error": "Invalid conversion ID format. A valid UUID is required."})

    raw_path = event.get("rawPath") or event.get("path") or event.get("resource", "")

    if http_method == "GET" and ("download" in raw_path or "download" in event.get("resource", "")):
        return handle_download(conversion_id)
    elif http_method == "DELETE":
        return handle_delete(conversion_id)
    else:
        action = (event.get("queryStringParameters") or {}).get("action")
        if action == "delete" or http_method == "DELETE":
            return handle_delete(conversion_id)
        return handle_download(conversion_id)
