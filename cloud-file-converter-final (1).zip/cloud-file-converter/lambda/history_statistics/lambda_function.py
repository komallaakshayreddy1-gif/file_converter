import json
import os
import decimal
import base64
import logging
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configuration from Environment Variables with secure defaults
TABLE_NAME = os.environ.get("TABLE_NAME", "FileConversions")
ALLOWED_ORIGIN = os.environ.get("ALLOWED_ORIGIN", "*")
GSI_INDEX_NAME = os.environ.get("GSI_INDEX_NAME", "CreatedAtIndex")

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

class DecimalEncoder(json.JSONEncoder):
    """Helper class to convert DynamoDB Decimal types to standard Python int/float."""
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 == 0:
                return int(o)
            return float(o)
        return super(DecimalEncoder, self).default(o)

def get_cors_headers():
    return {
        "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "GET,OPTIONS",
        "Content-Type": "application/json"
    }

def build_response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": get_cors_headers(),
        "body": json.dumps(body, cls=DecimalEncoder)
    }

def encode_next_token(last_evaluated_key):
    """Encodes a DynamoDB LastEvaluatedKey into a URL-safe base64 string."""
    if not last_evaluated_key:
        return None
    try:
        # Convert Decimal values to int/float for JSON serialization
        serialized = json.dumps(last_evaluated_key, cls=DecimalEncoder)
        return base64.urlsafe_b64encode(serialized.encode("utf-8")).decode("utf-8")
    except Exception as e:
        logger.warning(f"Failed to encode next_token: {str(e)}")
        return None

def decode_next_token(token_str):
    """Decodes a base64 token string back into a DynamoDB ExclusiveStartKey dict."""
    if not token_str:
        return None
    try:
        decoded_bytes = base64.urlsafe_b64decode(token_str.encode("utf-8"))
        data = json.loads(decoded_bytes.decode("utf-8"))
        # Convert numbers back to Decimal for DynamoDB compatibility
        return json.loads(json.dumps(data), parse_float=decimal.Decimal)
    except Exception as e:
        logger.warning(f"Failed to decode next_token: {str(e)}")
        return None

def get_history(query_params):
    """
    Retrieves conversion history sorted newest first.
    Uses GSI CreatedAtIndex for high-performance querying and pagination,
    with an automatic fallback to scan if the GSI is not yet configured.
    """
    limit = 20
    if query_params and "limit" in query_params:
        try:
            limit = min(max(int(query_params["limit"]), 1), 100)
        except ValueError:
            limit = 20

    start_key = None
    if query_params and "next_token" in query_params:
        start_key = decode_next_token(query_params["next_token"])

    items = []
    next_token = None

    # Preferred Approach: Query the Global Secondary Index (CreatedAtIndex)
    # Partition Key: job_type="CONVERSION", Sort Key: created_at (ScanIndexForward=False gives newest first)
    try:
        query_kwargs = {
            "IndexName": GSI_INDEX_NAME,
            "KeyConditionExpression": Key("job_type").eq("CONVERSION"),
            "ScanIndexForward": False,  # Newest records first
            "Limit": limit
        }
        if start_key:
            query_kwargs["ExclusiveStartKey"] = start_key

        response = table.query(**query_kwargs)
        items = response.get("Items", [])
        last_eval_key = response.get("LastEvaluatedKey")
        next_token = encode_next_token(last_eval_key)

        return build_response(200, {
            "items": items,
            "count": len(items),
            "next_token": next_token,
            "source": "index_query"
        })

    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "")
        # If GSI does not exist or is still building, seamlessly fall back to Scan
        if error_code in ("ValidationException", "ResourceNotFoundException"):
            logger.info("GSI CreatedAtIndex not available, falling back to table scan.")
        else:
            logger.exception("Error querying GSI in get_history")
            raise

    # Fallback Approach: Table Scan
    scan_kwargs = {
        "ProjectionExpression": "conversion_id, original_filename, original_format, output_format, original_size, converted_size, #st, created_at, completed_at, conversion_time_ms, error_message",
        "ExpressionAttributeNames": {
            "#st": "status"
        },
        "Limit": limit
    }
    if start_key:
        scan_kwargs["ExclusiveStartKey"] = start_key

    response = table.scan(**scan_kwargs)
    items = response.get("Items", [])
    last_eval_key = response.get("LastEvaluatedKey")
    next_token = encode_next_token(last_eval_key)

    # Sort descending by created_at timestamp
    items.sort(key=lambda x: str(x.get("created_at") or ""), reverse=True)

    return build_response(200, {
        "items": items,
        "count": len(items),
        "next_token": next_token,
        "source": "table_scan"
    })

def get_statistics():
    """
    Calculates aggregated statistics across ALL conversion records in DynamoDB.
    Paginates through the entire table without arbitrary cutoffs to ensure 100% complete metrics.
    """
    scan_kwargs = {
        "ProjectionExpression": "conversion_id, #st, original_size, converted_size, original_format, output_format",
        "ExpressionAttributeNames": {
            "#st": "status"
        }
    }

    total_uploaded = 0
    total_completed = 0
    total_failed = 0
    total_processing = 0
    total_original_storage_bytes = 0
    total_converted_storage_bytes = 0
    format_breakdown = {}

    response = table.scan(**scan_kwargs)
    items = response.get("Items", [])

    while True:
        for item in items:
            total_uploaded += 1
            st = str(item.get("status") or "").upper()
            orig_size = int(item.get("original_size") or 0)
            conv_size = int(item.get("converted_size") or 0)

            total_original_storage_bytes += orig_size

            if st == "COMPLETED":
                total_completed += 1
                total_converted_storage_bytes += conv_size
            elif st == "FAILED":
                total_failed += 1
            elif st in ("PENDING", "PROCESSING"):
                total_processing += 1

            # Format statistics
            orig_fmt = item.get("original_format")
            out_fmt = item.get("output_format")
            if orig_fmt and out_fmt:
                pair_key = f"{orig_fmt}_TO_{out_fmt}"
                format_breakdown[pair_key] = format_breakdown.get(pair_key, 0) + 1

        if "LastEvaluatedKey" in response:
            scan_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
            response = table.scan(**scan_kwargs)
            items = response.get("Items", [])
        else:
            break

    stats = {
        "total_files_uploaded": total_uploaded,
        "total_conversions_completed": total_completed,
        "total_failed_conversions": total_failed,
        "total_files_processing": total_processing,
        "total_original_storage_bytes": total_original_storage_bytes,
        "total_converted_storage_bytes": total_converted_storage_bytes,
        "format_statistics": format_breakdown
    }

    return build_response(200, stats)

def lambda_handler(event, context):
    """
    Routes GET requests for /history and /statistics.
    """
    http_method = event.get("httpMethod") or event.get("requestContext", {}).get("http", {}).get("method")
    if http_method == "OPTIONS":
        return build_response(200, {"message": "OK"})

    raw_path = event.get("rawPath") or event.get("path") or event.get("resource", "")
    query_params = event.get("queryStringParameters") or {}

    try:
        if "statistics" in raw_path:
            return get_statistics()
        elif "history" in raw_path:
            return get_history(query_params)
        else:
            action = query_params.get("action", "history")
            if action == "statistics":
                return get_statistics()
            return get_history(query_params)

    except ClientError as e:
        logger.exception("ClientError in history_statistics handler")
        return build_response(500, {
            "error": "Failed to read records from database."
        })
    except Exception as e:
        logger.exception("Unexpected exception in history_statistics handler")
        return build_response(500, {
            "error": "Internal server error occurred while retrieving data."
        })
