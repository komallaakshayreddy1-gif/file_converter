# Amazon DynamoDB Setup Guide

This guide details how to create and configure the Amazon DynamoDB table and Global Secondary Index (GSI) for tracking file conversion jobs, ordering by timestamp, and managing pagination.

---

## 1. Table Specifications

- **Table Name**: `FileConversions`
- **Partition Key (Primary Key)**: `conversion_id` (Type: `String`)
- **Sort Key**: None
- **Table Class**: Standard
- **Capacity Mode**: **On-demand** (recommended for variable project workloads)

---

## 2. Global Secondary Index (GSI): `CreatedAtIndex`

To return the **newest records first** efficiently and support reliable pagination without scanning the entire table, a Global Secondary Index is configured:

- **Index Name**: `CreatedAtIndex`
- **Partition Key**: `job_type` (Type: `String`)
- **Sort Key**: `created_at` (Type: `String`)
- **Attribute Projection**: `ALL`

> **How it works:**
> When a conversion is created in `upload_handler`, it includes `"job_type": "CONVERSION"`.
> The `history_statistics` Lambda performs a `Query` on `CreatedAtIndex` with `ScanIndexForward=False`, which natively returns newest records first with `LastEvaluatedKey` pagination. The Lambda has a best-effort table-scan fallback if the index is unavailable. That fallback sorts only the current page and therefore does **not** guarantee globally newest-first ordering. Create the GSI and wait until its status is **Active** before testing history.

---

## 3. Step-by-Step Creation in AWS Console

### Step A: Create the Base Table
1. Open the **Amazon DynamoDB Console**: [https://console.aws.amazon.com/dynamodb/](https://console.aws.amazon.com/dynamodb/).
2. Click **Create table**.
3. **Table name**: Enter `FileConversions`.
4. **Partition key**: Enter `conversion_id`, select `String`.
5. Under **Table settings**, select **Customize settings**:
   - **Table class**: DynamoDB Standard
   - **Read/write capacity settings**: Select **On-demand**.
   - **Encryption at rest**: Amazon DynamoDB owned key.
6. Click **Create table**.

### Step B: Create the Global Secondary Index (`CreatedAtIndex`)
1. Once the table status is **Active**, click into `FileConversions`.
2. Click the **Indexes** tab.
3. Click **Create index**.
4. **Partition key**: Enter `job_type`, select `String`.
5. **Sort key**: Enter `created_at`, select `String`.
6. **Index name**: Enter `CreatedAtIndex`.
7. **Attribute projections**: Select **All**.
8. Click **Create index**.
*(The index status will show "Creating" and become "Active" within 1-2 minutes).*

---

## 4. Item Schema & Attributes

| Attribute Name | DynamoDB Type | Description |
|---|---|---|
| `conversion_id` | String (PK) | Unique UUID generated per conversion request (e.g. `a3f9e8d1-...`) |
| `job_type` | String (GSI PK) | Static string `"CONVERSION"` grouping jobs for chronological indexing |
| `original_filename` | String | Sanitized original uploaded filename (e.g. `sample.png`) |
| `original_format` | String | Source format (`PNG`, `JPG`, `WEBP`) |
| `output_format` | String | Target conversion format (`JPG`, `PNG`, `WEBP`) |
| `original_s3_key` | String | S3 storage key under `uploads/<conversion_id>/<filename>` |
| `converted_s3_key` | String | S3 storage key under `converted/<conversion_id>/<filename>` |
| `original_size` | Number | Original file size in bytes |
| `converted_size` | Number | Converted file size in bytes |
| `status` | String | `PENDING`, `PROCESSING`, `COMPLETED`, or `FAILED` |
| `created_at` | String (GSI SK) | ISO-8601 UTC timestamp (e.g. `2026-11-07T11:45:00.000Z`) |
| `completed_at` | String | ISO-8601 UTC timestamp of completion/failure |
| `conversion_time_ms` | Number | Conversion duration in milliseconds |
| `error_message` | String | Error details if status is `FAILED` (null otherwise) |
