# AWS Lambda Functions Setup Guide

This guide details how to create and configure the five AWS Lambda functions in the AWS Management Console with exact environment variables, memory, timeouts, and layers.

---

## 1. Prerequisites Checklist
- [x] S3 Storage bucket created (e.g., `cloud-file-converter-storage-xxxx`).
- [x] DynamoDB table created (`FileConversions`) with GSI `CreatedAtIndex`.
- [x] Pillow Lambda Layer created (`Pillow-Python312`).
- [x] IAM execution role created using the `CombinedSingleRolePolicy` from `aws/iam_permissions.json` for a simple college demo, or preferably the five role-specific policies in that file for least privilege.

**Important:** If using the shared role, use the updated `CombinedSingleRolePolicy`, which includes CloudWatch Logs permissions. Replace `YOUR_STORAGE_BUCKET_NAME` in the policy with your exact bucket name before creating the policy. Use the same AWS region and account for all resources.

---

## 2. Lambda Function Specifications

| Function Name | Code Source | Trigger / Route | Memory / Timeout | Layer Required |
|---|---|---|---|---|
| `CloudFileConverter-UploadHandler` | `lambda/upload_handler/lambda_function.py` | API Gateway: `POST /upload-url` | 128 MB / 10s | None |
| `CloudFileConverter-FileConverter` | `lambda/file_converter/lambda_function.py` | S3: `ObjectCreated` on `uploads/` | 512 MB / 60s | **Pillow-Python312** |
| `CloudFileConverter-ConversionStatus` | `lambda/conversion_status/lambda_function.py` | API Gateway: `GET /conversion/{id}` | 128 MB / 10s | None |
| `CloudFileConverter-HistoryStatistics` | `lambda/history_statistics/lambda_function.py` | API Gateway: `GET /history`, `GET /statistics` | 128 MB / 15s | None |
| `CloudFileConverter-DownloadDelete` | `lambda/download_delete/lambda_function.py` | API Gateway: `GET /download/{id}`, `DELETE /conversion/{id}` | 128 MB / 10s | None |

---

## 3. Step-by-Step Creation Instructions

### Function 1: `CloudFileConverter-UploadHandler`
1. Open the **AWS Lambda Console**: [https://console.aws.amazon.com/lambda/](https://console.aws.amazon.com/lambda/).
2. Click **Create function** -> **Author from scratch**.
3. **Function name**: `CloudFileConverter-UploadHandler`.
4. **Runtime**: `Python 3.12`.
5. **Architecture**: `x86_64`.
6. **Execution role**: Choose **Use an existing role** -> select `CloudFileConverterLambdaRole`.
7. Click **Create function**.
8. Copy the entire code from `lambda/upload_handler/lambda_function.py` into the in-browser code editor.
9. Click **Deploy**.
10. Navigate to **Configuration** tab -> **Environment variables** -> click **Edit**:
    - `BUCKET_NAME` = `your-actual-storage-bucket-name`
    - `TABLE_NAME` = `FileConversions`
    - `MAX_FILE_SIZE_BYTES` = `10485760` (10 MB)
    - `ALLOWED_ORIGIN` = `*` for initial testing only; restrict it to your frontend origin before sharing for initial testing only (replace with the exact frontend origin before sharing the demo)
11. Click **Save**.

---

### Function 2: `CloudFileConverter-FileConverter`
1. In Lambda Console, click **Create function** -> **Author from scratch**.
2. **Function name**: `CloudFileConverter-FileConverter`.
3. **Runtime**: `Python 3.12`.
4. **Architecture**: `x86_64`.
5. **Execution role**: Select `CloudFileConverterLambdaRole`.
6. Click **Create function**.
7. Copy the code from `lambda/file_converter/lambda_function.py` into the editor and click **Deploy**.
8. **Configure Memory & Timeout**:
   - Go to **Configuration** tab -> **General configuration** -> click **Edit**.
   - **Memory**: Set to `512 MB`.
   - **Timeout**: Set to `1 min 0 sec`.
   - Click **Save**.
9. **Configure Environment Variables**:
   - In **Configuration** tab -> **Environment variables** -> click **Edit**:
     - `BUCKET_NAME` = `your-actual-storage-bucket-name`
     - `TABLE_NAME` = `FileConversions`
     - `MAX_FILE_SIZE_BYTES` = `10485760`
   - Click **Save**.
10. **Attach Pillow Layer**:
    - Scroll down to the **Layers** card at the bottom of the Lambda page.
    - Click **Add a layer**.
    - Under Choose a layer, select **Custom layers**.
    - Layer: Select `Pillow-Python312`.
    - Version: Select Version `1`.
    - Click **Add**.

---

### Function 3: `CloudFileConverter-ConversionStatus`
1. Lambda Console -> click **Create function**.
2. **Function name**: `CloudFileConverter-ConversionStatus`.
3. **Runtime**: `Python 3.12`.
4. **Execution role**: Select `CloudFileConverterLambdaRole`.
5. Click **Create function**.
6. Paste code from `lambda/conversion_status/lambda_function.py` and click **Deploy**.
7. In **Configuration** -> **Environment variables**:
   - `TABLE_NAME` = `FileConversions`
   - `ALLOWED_ORIGIN` = `*` for initial testing only; restrict it to your frontend origin before sharing
8. Click **Save**.

---

### Function 4: `CloudFileConverter-HistoryStatistics`
1. Lambda Console -> click **Create function**.
2. **Function name**: `CloudFileConverter-HistoryStatistics`.
3. **Runtime**: `Python 3.12`.
4. **Execution role**: Select `CloudFileConverterLambdaRole`.
5. Click **Create function**.
6. Paste code from `lambda/history_statistics/lambda_function.py` and click **Deploy**.
7. In **Configuration** -> **General configuration**:
   - **Timeout**: Set to `15 sec`.
   - Click **Save**.
8. In **Configuration** -> **Environment variables**:
   - `TABLE_NAME` = `FileConversions`
   - `GSI_INDEX_NAME` = `CreatedAtIndex`
   - `ALLOWED_ORIGIN` = `*` for initial testing only; restrict it to your frontend origin before sharing
9. Click **Save**.

---

### Function 5: `CloudFileConverter-DownloadDelete`
1. Lambda Console -> click **Create function**.
2. **Function name**: `CloudFileConverter-DownloadDelete`.
3. **Runtime**: `Python 3.12`.
4. **Execution role**: Select `CloudFileConverterLambdaRole`.
5. Click **Create function**.
6. Paste code from `lambda/download_delete/lambda_function.py` and click **Deploy**.
7. In **Configuration** -> **Environment variables**:
   - `BUCKET_NAME` = `your-actual-storage-bucket-name`
   - `TABLE_NAME` = `FileConversions`
   - `DOWNLOAD_EXPIRATION_SECONDS` = `300`
   - `ALLOWED_ORIGIN` = `*` for initial testing only; restrict it to your frontend origin before sharing
8. Click **Save**.
