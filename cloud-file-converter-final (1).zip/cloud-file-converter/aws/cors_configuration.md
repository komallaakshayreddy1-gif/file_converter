# Comprehensive CORS Configuration Guide

Cross-Origin Resource Sharing (CORS) is required in two distinct communication paths:
1. **Frontend to API Gateway / Lambda**: The browser fetches JSON endpoints (`/upload-url`, `/conversion/{id}`, `/history`, `/statistics`, `/download/{id}`, `/conversion/{id}`).
2. **Frontend to Amazon S3**: The browser uploads the raw file directly to S3 via presigned `PUT` URLs.

---

## 1. Amazon S3 Bucket CORS Configuration

When the browser sends a binary file via `PUT` directly to S3, the browser first issues an `OPTIONS` preflight request. If S3 CORS is missing, the browser blocks the upload with `CORS Preflight Did Not Succeed`.

### Configuration in S3 Console:
1. Open your storage bucket in the S3 Console.
2. Navigate to **Permissions** tab -> scroll down to **Cross-origin resource sharing (CORS)** -> click **Edit**.
3. Paste the following configuration:

```json
[
  {
    "AllowedHeaders": [
      "*"
    ],
    "AllowedMethods": [
      "PUT",
      "GET",
      "HEAD"
    ],
    "AllowedOrigins": [
      "http://YOUR_FRONTEND_WEBSITE_ENDPOINT"
    ],
    "ExposeHeaders": [
      "ETag",
      "x-amz-server-side-encryption"
    ],
    "MaxAgeSeconds": 3000
  }
]
```

### Production Hardening:
In production, restrict `AllowedOrigins` from `*` to your actual frontend hosting domain (S3 static website or CloudFront distribution):
```json
"AllowedOrigins": [
  "http://your-web-bucket.s3-website-us-east-1.amazonaws.com",
  "https://d111111abcdef8.cloudfront.net"
]
```

---

## 2. API Gateway CORS Configuration

### For HTTP API (Recommended):
1. In the **API Gateway Console**, select your HTTP API (`CloudFileConverterAPI`).
2. In the left navigation, click **CORS** -> click **Configure**.
3. Set the following values:
   - **Access-Control-Allow-Origin**: `*` (or your S3 website URL in production)
   - **Access-Control-Allow-Headers**: `Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token`
   - **Access-Control-Allow-Methods**: `GET, POST, DELETE, OPTIONS`
   - **Access-Control-Max-Age**: `300`
4. Click **Save**.

---

## 3. Lambda Response CORS Headers

All Lambda functions return CORS headers on every response:

```python
def get_cors_headers():
    return {
        "Access-Control-Allow-Origin": os.environ.get("ALLOWED_ORIGIN", "*"),
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS",
        "Content-Type": "application/json"
    }
```

Additionally, each Lambda intercepts `OPTIONS` requests and immediately responds with HTTP 200:
```python
if http_method == "OPTIONS":
    return build_response(200, {"message": "OK"})
```

### Configuring Allowed Origin in Lambdas:
If you want to restrict origins in production, set the environment variable on all 5 Lambda functions:
- `ALLOWED_ORIGIN` = `http://your-frontend-bucket.s3-website-us-east-1.amazonaws.com`

---

## 4. CORS Diagnostic Checklist

| Symptom | Cause | Solution |
|---|---|---|
| `Cross-Origin Request Blocked ... Reason: CORS Missing Allow Header` | S3 PUT request headers not permitted | Ensure `AllowedHeaders: ["*"]` is present in S3 CORS. |
| `Method Not Allowed` on preflight OPTIONS | API Gateway does not have an OPTIONS route or CORS enabled | Verify API Gateway CORS configuration has `OPTIONS` in AllowedMethods. |
| Browser blocks reading converted download URL | Missing ExposeHeaders | Add `Content-Disposition` and `ETag` to ExposeHeaders in S3 CORS. |
