# Final Deployment Checklist

Use this checklist in order. Do not skip ahead.

## Before AWS
- [ ] Choose one AWS Region and use it for S3, Lambda, DynamoDB, and API Gateway.
- [ ] Choose a globally unique private storage bucket name.
- [ ] Replace `YOUR_STORAGE_BUCKET_NAME` in the IAM policy with that exact name.
- [ ] Create the `FileConversions` DynamoDB table and `CreatedAtIndex` GSI; wait until both are ACTIVE.
- [ ] Create the Pillow layer for Python 3.12 / x86_64.

## AWS configuration
- [ ] Create the Lambda execution role(s). For the quick demo, use the corrected `CombinedSingleRolePolicy`; for stronger isolation use the five role-specific policies.
- [ ] Create and deploy all five Python 3.12 Lambda functions.
- [ ] Set each function's environment variables exactly as listed in `aws/lambda_setup.md`.
- [ ] Attach the Pillow layer only to `CloudFileConverter-FileConverter`.
- [ ] Configure the S3 event notification for `s3:ObjectCreated:*` with prefix `uploads/` only.
- [ ] Create the HTTP API routes exactly as listed in `aws/api_gateway_setup.md`.
- [ ] Configure API Gateway CORS and storage-bucket CORS.
- [ ] Keep the storage bucket private and Block Public Access enabled.
- [ ] Deploy `frontend/index.html` to the website bucket.
- [ ] Set the API Gateway invoke URL in the frontend's API URL setting.

## End-to-end test
- [ ] Upload a small PNG and convert it to JPG.
- [ ] Confirm the original appears under `uploads/`.
- [ ] Confirm the converted image appears under `converted/`.
- [ ] Confirm DynamoDB status changes from PENDING to PROCESSING to COMPLETED.
- [ ] Download and open the converted image.
- [ ] Test history, statistics, and delete.
- [ ] Test one invalid file and confirm a readable failure message.
- [ ] If anything fails, inspect the relevant Lambda's CloudWatch log group.

**Important:** The included tests are local unit tests with AWS services mocked. They do not replace this end-to-end AWS test.
