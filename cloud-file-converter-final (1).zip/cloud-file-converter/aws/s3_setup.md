# Amazon S3 Setup Guide

This guide provides step-by-step instructions for creating and configuring the Amazon S3 buckets for the **Cloud-Based File Converter**.

---

## 1. Create the Storage S3 Bucket

The application uses an S3 bucket to store both uploaded original files and converted outputs.

### Steps in AWS Management Console:
1. Open the **Amazon S3 Console**: [https://console.aws.amazon.com/s3/](https://console.aws.amazon.com/s3/).
2. Click **Create bucket**.
3. **Bucket name**: Choose a globally unique name, e.g. `cloud-file-converter-storage-xxxx` (replace `xxxx` with your initials or random numbers).
4. **AWS Region**: Select your preferred region (e.g., `us-east-1` or `ap-south-1`). *All project services must be in this same region.*
5. **Object Ownership**: Select **Bucket owner enforced** (recommended).
6. **Block Public Access settings for this bucket**: Keep **Block all public access** checked (ENABLED). Files are uploaded and downloaded securely using Presigned URLs; the bucket itself remains private.
7. **Bucket Versioning**: Optional (Disabled or Enabled).
8. **Default encryption**: Amazon S3-managed keys (SSE-S3).
9. Click **Create bucket**.

---

## 2. Create the Required Prefixes (Folders)

Once the bucket is created:
1. Click into your new bucket.
2. Click **Create folder**.
3. Folder name: `uploads` -> click **Create folder**.
4. Click **Create folder** again.
5. Folder name: `converted` -> click **Create folder**.

> **CRITICAL ARCHITECTURAL REQUIREMENT**:
> - `uploads/`: Where original files uploaded by users via presigned URLs are stored.
> - `converted/`: Where the `file_converter` Lambda function writes the converted image.
>
> Keeping separate prefixes ensures the S3 event notification only triggers conversions for new uploads, eliminating the risk of recursive Lambda loops.

---

## 3. Configure S3 Event Notification (Trigger for File Converter)

After creating the `CloudFileConverter-FileConverter` Lambda function (see `lambda_setup.md`), connect the S3 event:

1. In your S3 storage bucket, go to the **Properties** tab.
2. Scroll down to **Event notifications** and click **Create event notification**.
3. **Event name**: `NewFileUploadTrigger`.
4. **Prefix**: `uploads/` *(CRITICAL: You MUST enter `uploads/` to prevent infinite conversion triggers)*.
5. **Event types**: Select **All object create events** (`s3:ObjectCreated:*`).
6. **Destination**: Select **Lambda function**.
7. **Lambda function**: Choose `CloudFileConverter-FileConverter` from the dropdown.
8. Click **Save changes**.

---

## 4. Configure S3 CORS (Cross-Origin Resource Sharing)

Direct browser-to-S3 uploads via presigned URLs require CORS authorization.

1. In your S3 storage bucket, go to the **Permissions** tab.
2. Scroll down to **Cross-origin resource sharing (CORS)** and click **Edit**.
3. Paste the following JSON configuration:

```json
[
  {
    "AllowedHeaders": [
      "*"
    ],
    "AllowedMethods": [
      "PUT",
      "GET",
      "HEAD"
    ],
    "AllowedOrigins": [
      "http://YOUR_FRONTEND_WEBSITE_ENDPOINT"
    ],
    "ExposeHeaders": [
      "ETag",
      "x-amz-server-side-encryption"
    ],
    "MaxAgeSeconds": 3000
  }
]
```
*(In production, replace `*` under `AllowedOrigins` with your frontend S3 website domain or CloudFront URL).*
4. Click **Save changes**.

---

## 5. Hosting the Frontend via S3 Static Website Hosting

To host `frontend/index.html` on Amazon S3:

1. Click **Create bucket** and name it e.g. `cloud-file-converter-web-xxxx`.
2. Select the same AWS Region as your other services.
3. Uncheck **Block all public access** and acknowledge the warning checkbox.
4. Click **Create bucket**.
5. In your web bucket's **Properties** tab, scroll to **Static website hosting** -> click **Edit**:
   - Select **Enable**.
   - **Hosting type**: Host a static website.
   - **Index document**: Enter `index.html`.
   - Click **Save changes**.
6. In your web bucket's **Permissions** tab, scroll to **Bucket policy** -> click **Edit**:
   Paste the following policy (replace `YOUR_WEB_BUCKET_NAME` with your actual bucket name):
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::YOUR_WEB_BUCKET_NAME/*"
    }
  ]
}
```
7. Click **Save changes**.
8. Go to the **Objects** tab and upload `frontend/index.html`.
9. Access your live website using the **Bucket website endpoint** URL displayed at the bottom of the **Properties** tab!
