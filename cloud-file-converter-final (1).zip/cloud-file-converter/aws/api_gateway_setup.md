# Amazon API Gateway Setup Guide

This guide describes how to configure **Amazon API Gateway** (HTTP API v2) to route frontend HTTP requests to your five AWS Lambda functions.

---

## 1. Create the HTTP API

1. Open the **Amazon API Gateway Console**: [https://console.aws.amazon.com/apigateway/](https://console.aws.amazon.com/apigateway/).
2. Under **HTTP API**, click **Build**.
3. In Step 1 (Create an API):
   - **API name**: Enter `CloudFileConverterAPI`.
4. Click **Next**.
5. In Step 2 (Configure routes): Click **Next** (we will create routes and integrations together).
6. In Step 3 (Define stages): Leave the stage name as `$default` with **Auto-deploy** enabled.
7. Click **Next** -> Click **Create**.

---

## 2. Configure the 6 Routes & Lambda Integrations

In the left navigation menu under `CloudFileConverterAPI`, click **Routes**:

### Route 1: `POST /upload-url`
1. Click **Create**.
2. Method: Select `POST`.
3. Path: Enter `/upload-url`.
4. Click **Create**.
5. With `/upload-url` selected, click **Attach integration**.
6. Click **Create and attach an integration**:
   - Integration type: `Lambda function`
   - Lambda function: Select `CloudFileConverter-UploadHandler`
   - Click **Create**.

### Route 2: `GET /conversion/{id}`
1. Click **Create**.
2. Method: Select `GET`.
3. Path: Enter `/conversion/{id}`.
4. Click **Create**.
5. Click **Attach integration** -> select `CloudFileConverter-ConversionStatus`.

### Route 3: `GET /history`
1. Click **Create**.
2. Method: Select `GET`.
3. Path: Enter `/history`.
4. Click **Create**.
5. Click **Attach integration** -> select `CloudFileConverter-HistoryStatistics`.

### Route 4: `GET /statistics`
1. Click **Create**.
2. Method: Select `GET`.
3. Path: Enter `/statistics`.
4. Click **Create**.
5. Click **Attach integration** -> select `CloudFileConverter-HistoryStatistics`.

### Route 5: `GET /download/{id}`
1. Click **Create**.
2. Method: Select `GET`.
3. Path: Enter `/download/{id}`.
4. Click **Create**.
5. Click **Attach integration** -> select `CloudFileConverter-DownloadDelete`.

### Route 6: `DELETE /conversion/{id}`
1. Click **Create**.
2. Method: Select `DELETE`.
3. Path: Enter `/conversion/{id}`.
4. Click **Create**.
5. Click **Attach integration** -> select `CloudFileConverter-DownloadDelete`.

---

## 3. Configure CORS in API Gateway

1. In the left navigation, click **CORS**.
2. Click **Configure**.
3. Enter the following parameters:
   - **Access-Control-Allow-Origin**: `*` (or your S3 website URL in production)
   - **Access-Control-Allow-Headers**: `Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token`
   - **Access-Control-Allow-Methods**: `GET, POST, DELETE, OPTIONS`
   - **Access-Control-Max-Age**: `300`
4. Click **Save**.

---

## 4. Obtain the Invoke URL

1. Click on **Stages** in the left menu.
2. Select `$default`.
3. Copy the **Invoke URL** (e.g. `https://abc123def4.execute-api.us-east-1.amazonaws.com`).
4. This URL is your `API_BASE_URL` to configure in `frontend/index.html` or enter in the frontend UI modal.
