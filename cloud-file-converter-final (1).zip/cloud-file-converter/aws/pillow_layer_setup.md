# Packaging Pillow (PIL) for AWS Lambda

AWS Lambda runs on Amazon Linux (x86_64 or arm64). Since **Pillow** contains C/native compiled binaries (e.g., `libjpeg`, `libpng`, `libwebp`), installing it on Windows directly into a zip file will not work inside Lambda.

Follow one of the tested methods below to create a compatible **Pillow Lambda Layer**.

---

## Method 1: Download Linux Wheel directly (No Docker required, works on Windows!)

You can run `pip` with `--platform manylinux2014_x86_64` to download the exact Linux-compatible binary wheels right from your Windows PowerShell or Command Prompt.

### Step-by-Step for Windows:

1. Open PowerShell and create a directory structure:
```powershell
mkdir -p pillow-layer/python
cd pillow-layer
```

2. Download and install Pillow targetting the Lambda Python 3.12 Linux environment:
```powershell
pip install `
  --platform manylinux2014_x86_64 `
  --target python `
  --implementation cp `
  --python-version 3.12 `
  --only-binary=:all: `
  --upgrade `
  Pillow
```

3. Create the deployment ZIP file:
```powershell
Compress-Archive -Path python -DestinationPath pillow-layer.zip
```

*(Note: The zip file MUST contain the root folder named `python/` which contains `PIL/` and `pillow-*.dist-info/`).*

4. Proceed to Section 3 below to upload to AWS Lambda.

---

## Method 2: Build with Docker (Universal)

If you have Docker Desktop running:

```bash
docker run --rm -v "$PWD":/var/task public.ecr.aws/sam/build-python3.12:latest \
  pip install Pillow -t /var/task/python

zip -r pillow-layer.zip python
```

---

## Method 3: Use Klayers Pre-built Layer ARN (Fastest)

If you prefer using an existing verified community layer for Python in your region, Klayers maintains up-to-date Python 3.12 / 3.11 Pillow layers:

- Example for `us-east-1` (Python 3.12):
  Search or add layer ARN:
  `arn:aws:lambda:us-east-1:770693421928:layer:Klayers-p312-Pillow:1`
  *(Note: Layer versions and ARNs vary by AWS region).*

---

## 4. Upload Layer to AWS Lambda Console

1. Open the **AWS Lambda Console**: [https://console.aws.amazon.com/lambda/](https://console.aws.amazon.com/lambda/).
2. In the left navigation, click **Layers** -> **Create layer**.
3. **Name**: `Pillow-Python312`.
4. **Description**: `Pillow image library for Python 3.12 x86_64`.
5. Select **Upload a .zip file** and choose `pillow-layer.zip`.
6. **Compatible architectures**: Select `x86_64`.
7. **Compatible runtimes**: Select `Python 3.12` (and `Python 3.11` if desired).
8. Click **Create**.
9. Note the Layer ARN or use it in the `file_converter` Lambda function settings.
