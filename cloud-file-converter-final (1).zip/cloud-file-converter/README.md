# Cloud-Based File Converter (Project 36)

> **College Product Number:** 36  
> **Architecture:** AWS Serverless (Amazon S3, AWS Lambda, Amazon API Gateway, Amazon DynamoDB, Amazon CloudWatch, AWS IAM)  
> **Frontend:** Pure Vanilla HTML5, CSS3, JavaScript in a single `index.html` file (No frameworks, S3 Static Web Hosting ready)

---

## 1. System Architecture & Workflow

```text
User Browser
    │
    ▼
index.html hosted on Amazon S3 Static Hosting
    │
    ├─────────────────────────────┬─────────────────────────────┐
    │                             │                             │
    ▼ [1. POST /upload-url]       ▼ [4. Poll /conversion/{id}]  ▼ [6. GET /download/{id}]
API Gateway (HTTP API v2)     API Gateway                   API Gateway
    │                             │                             │
    ▼                             ▼                             ▼
Lambda (Upload Handler)       Lambda (Conversion Status)    Lambda (Download & Delete)
    │                             ▲                             ▲
    ├─► DynamoDB (PENDING)        │ Reads Item                  │ Reads Item & signs URL
    ▼ Signs S3 PUT URL            │                             │
User Browser                      │                             ▼
    │                             │                     User Downloads File
    ▼ [2. Direct S3 Upload PUT]   │
S3 Bucket: uploads/               │
    │                             │
    ▼ [3. S3 ObjectCreated Event] │
Lambda (File Converter + Pillow)  │
    │                             │
    ├─► S3 Bucket: converted/     │
    └─► DynamoDB (COMPLETED) ─────┘
```

---

## 2. Directory Structure

```text
cloud-file-converter/
│
├── frontend/
│   └── index.html                 # 100% complete single-file frontend (Vanilla HTML5, CSS3, JS)
│
├── lambda/
│   ├── upload_handler/
│   │   └── lambda_function.py     # Lambda 1: S3 presigned PUT URL generator & validation
│   ├── file_converter/
│   │   └── lambda_function.py     # Lambda 2: S3 event handler with Pillow image conversion
│   ├── conversion_status/
│   │   └── lambda_function.py     # Lambda 3: Status poller (PENDING/PROCESSING/COMPLETED/FAILED)
│   ├── history_statistics/
│   │   └── lambda_function.py     # Lambda 4: Paginated history (GSI CreatedAtIndex) & statistics
│   └── download_delete/
│       └── lambda_function.py     # Lambda 5: Presigned S3 download URL & resource deletion
│
├── aws/
│   ├── s3_setup.md                # Storage bucket, prefixes (uploads/, converted/), and web hosting
│   ├── lambda_setup.md            # Configuration, runtime, timeouts, and layer attachments
│   ├── api_gateway_setup.md       # HTTP API routes, integrations, and CORS configuration
│   ├── dynamodb_setup.md          # Table schema, partition keys, and GSI CreatedAtIndex
│   ├── iam_permissions.json       # Least-privilege IAM policy documents
│   ├── cors_configuration.md      # Comprehensive CORS settings for S3, API Gateway & Lambdas
│   └── pillow_layer_setup.md      # Step-by-step Pillow layer packaging guide for Python 3.12
│
├── tests/
│   └── test_converter_logic.py    # Comprehensive unit tests (25/25 passing)
│
└── README.md                      # Complete project documentation & manual AWS setup instructions
```

---

## 3. Supported Conversion Formats

All conversions use **Pillow (PIL)** with format-specific optimizations (handling transparency, blending onto white backgrounds for JPEG, preserving dimensions, high quality compression):

- **PNG to JPG** (Alpha transparency blended safely onto white)
- **JPG to PNG** (Lossless image reconstruction)
- **WEBP to JPG** (Web-optimized to universal format)
- **JPG to WEBP** (Standard to high-efficiency web compression)
- **PNG to WEBP** (Preserves alpha channel with webp compression)
- **WEBP to PNG** (Converts webp to lossless PNG)
- *JPEG is supported as an alias for JPG.*

---

## 4. Complete Step-by-Step AWS Setup Guide

Follow these 12 manual steps to set up your entire AWS infrastructure through the AWS Management Console:

### Step 1: Create the Storage S3 Bucket
1. Go to **Amazon S3 Console** -> **Create bucket**.
2. Name: e.g. `cloud-file-converter-storage-xxxx` (replace `xxxx` with unique numbers).
3. Region: Select your preferred region (e.g. `us-east-1`).
4. Keep **Block all public access** enabled (checked).
5. Click **Create bucket**.

### Step 2: Create the Prefixes (Folders)
1. In your storage bucket, click **Create folder**.
2. Folder name: `uploads` -> click **Create folder**.
3. Click **Create folder** again.
4. Folder name: `converted` -> click **Create folder**.

### Step 3: Configure S3 CORS
1. In the storage bucket, navigate to **Permissions** tab -> **Cross-origin resource sharing (CORS)** -> **Edit**.
2. Paste the configuration from `aws/cors_configuration.md`.
3. Click **Save changes**.

### Step 4: Create DynamoDB Table & GSI
1. Go to **DynamoDB Console** -> **Create table**.
2. Table name: `FileConversions`.
3. Partition key: `conversion_id` (`String`).
4. Under Table settings, select **Customize settings** -> Capacity mode: **On-demand**.
5. Click **Create table**.
6. Once Active, click the table -> **Indexes** tab -> **Create index**:
   - Partition key: `job_type` (`String`)
   - Sort key: `created_at` (`String`)
   - Index name: `CreatedAtIndex`
   - Attribute projections: `All`
   - Click **Create index**.

### Step 5: Create the IAM Execution Role
1. Go to **IAM Console** -> **Policies** -> **Create policy** -> **JSON**.
2. For the quickest classroom demo, copy `CombinedSingleRolePolicy` from `aws/iam_permissions.json`.
3. Replace every `YOUR_STORAGE_BUCKET_NAME` with the exact private storage bucket name, then create the policy as `CloudFileConverterPolicy`.
4. Go to **IAM Console** -> **Roles** -> **Create role**.
5. Trusted entity: **AWS service** -> **Lambda**.
6. Attach `CloudFileConverterPolicy` and name the role `CloudFileConverterLambdaRole`.
7. Use this role for all five functions only for the simple demo. For stronger least privilege, create five separate roles using the five entries under `RolePolicies` instead.

### Step 6: Create the Pillow Lambda Layer
1. In PowerShell / terminal, package Pillow for Python 3.12 (see `aws/pillow_layer_setup.md`):
   ```powershell
   pip install --platform manylinux2014_x86_64 --target python --implementation cp --python-version 3.12 --only-binary=:all: --upgrade Pillow
   Compress-Archive -Path python -DestinationPath pillow-layer.zip
   ```
2. Go to **Lambda Console** -> **Layers** -> **Create layer**.
3. Name: `Pillow-Python312`, upload `pillow-layer.zip`, select Runtime `Python 3.12`, Architecture `x86_64`.

### Step 7: Deploy the 5 Lambda Functions
Follow `aws/lambda_setup.md` to deploy:
1. `CloudFileConverter-UploadHandler` (`lambda/upload_handler/lambda_function.py`)
2. `CloudFileConverter-FileConverter` (`lambda/file_converter/lambda_function.py` + attach Pillow Layer, 512 MB memory, 60s timeout)
3. `CloudFileConverter-ConversionStatus` (`lambda/conversion_status/lambda_function.py`)
4. `CloudFileConverter-HistoryStatistics` (`lambda/history_statistics/lambda_function.py`, 15s timeout)
5. `CloudFileConverter-DownloadDelete` (`lambda/download_delete/lambda_function.py`)

Set only the environment variables listed for each function in `aws/lambda_setup.md`. Do not set `BUCKET_NAME` on functions that do not use S3. Use the same exact bucket name and table name wherever required.

For initial testing, `ALLOWED_ORIGIN` may be `*`; before sharing the application, replace it with the exact frontend origin in every Lambda and in S3/API Gateway CORS.

### Step 8: Configure S3 Event Notification
1. In S3 Storage bucket -> **Properties** tab -> **Event notifications** -> **Create event notification**.
2. Name: `NewFileUploadTrigger`.
3. Prefix: `uploads/` *(CRITICAL: Must be `uploads/` to prevent infinite loops)*.
4. Event types: **All object create events** (`s3:ObjectCreated:*`).
5. Destination: **Lambda function** -> select `CloudFileConverter-FileConverter`.
6. Click **Save changes**.

### Step 9: Create API Gateway (HTTP API v2)
1. Go to **API Gateway Console** -> **Create API** -> **HTTP API** -> **Build**.
2. Name: `CloudFileConverterAPI`.
3. Create the 6 routes:
   - `POST /upload-url` -> Integrate with `CloudFileConverter-UploadHandler`
   - `GET /conversion/{id}` -> Integrate with `CloudFileConverter-ConversionStatus`
   - `GET /history` -> Integrate with `CloudFileConverter-HistoryStatistics`
   - `GET /statistics` -> Integrate with `CloudFileConverter-HistoryStatistics`
   - `GET /download/{id}` -> Integrate with `CloudFileConverter-DownloadDelete`
   - `DELETE /conversion/{id}` -> Integrate with `CloudFileConverter-DownloadDelete`

### Step 10: Configure API Gateway CORS
1. In API Gateway -> **CORS** -> **Configure**:
   - Access-Control-Allow-Origin: `*`
   - Access-Control-Allow-Headers: `Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token`
   - Access-Control-Allow-Methods: `GET, POST, DELETE, OPTIONS`
2. Click **Save**.

### Step 11: Connect Frontend to API Gateway
1. Copy the **Invoke URL** from API Gateway (e.g. `https://abc123def.execute-api.us-east-1.amazonaws.com`).
2. Open `frontend/index.html`.
3. Set the invoke URL:
   ```javascript
   const CONFIG = {
     API_BASE_URL: "https://abc123def.execute-api.us-east-1.amazonaws.com"
   };
   ```
   *(Or click the top-right **Set API URL** pill in the browser to paste it into local storage).*

### Step 12: Host Frontend on S3
1. Create a second S3 bucket for web hosting: `cloud-file-converter-web-xxxx`.
2. Enable **Static website hosting** in Properties tab -> Index document: `index.html`.
3. Upload `frontend/index.html` to the bucket.
4. Add the public read bucket policy from `aws/s3_setup.md`.
5. Open the static website endpoint URL in your browser.

---

## 5. Security & Isolation Summary

- **Never Trust Frontend File Size**: `file_converter` executes an `s3_client.head_object()` call before reading any file bytes, enforcing maximum limits (10 MB) and rejecting 0-byte files.
- **Key Prefix Isolation**: `download_delete` strictly enforces that downloads and deletions must begin with `converted/{id}/` or `uploads/{id}/`, preventing unauthorized file access.
- **Path Traversal Protection**: Filenames are sanitized, and conversion IDs are validated strictly against UUID regex.
- **Recursion Loop Protection**: Converter explicitly rejects any S3 event whose key does not start with `uploads/`.
- **Duplicate Event Protection**: Converter checks DynamoDB status and skips already completed or currently processing records.
- **Least-Privilege IAM**: Granular policies provided for each Lambda function with restricted S3 prefixes and DynamoDB actions.

---

## 6. Resource Clean Up (Avoid Unnecessary Charges)

When finished demonstrating your project:
1. **Empty and delete S3 Buckets**: Empty all objects in `cloud-file-converter-storage-*` and `cloud-file-converter-web-*`, then delete both buckets.
2. **Delete DynamoDB Table**: Delete `FileConversions`.
3. **Delete API Gateway**: Delete `CloudFileConverterAPI`.
4. **Delete 5 Lambda Functions & Layer**: Delete the 5 Lambdas and `Pillow-Python312` layer.
5. **Delete IAM Role**: Delete `CloudFileConverterLambdaRole`.


---

## 5. Important Demo-Security and Scale Notes

- This is a **college demonstration project**, not a production multi-user service. The API routes do not implement user authentication or per-user authorization. Treat conversion IDs as unguessable references, and do not upload private or sensitive files.
- The storage bucket should remain private. Do not disable Block Public Access on the storage bucket.
- The separate frontend website bucket is public-read when using S3 static website hosting. S3 website endpoints use HTTP. For HTTPS, use CloudFront in front of the website bucket.
- `ALLOWED_ORIGIN = *` is suitable only for initial testing. Restrict API Gateway, Lambda response CORS, and storage-bucket CORS to your deployed frontend origin before sharing the demo.
- The statistics endpoint scans the DynamoDB table to aggregate all records. This is acceptable for a small classroom demo but can become slow or expensive as the table grows.
- The history endpoint is globally newest-first when `CreatedAtIndex` is ACTIVE. Its emergency table-scan fallback sorts only each returned page, so it cannot guarantee globally newest-first ordering. Create and wait for the GSI to become ACTIVE before testing history.
- Unit tests use mocked AWS services. Passing them does not prove that your AWS account resources, IAM policies, API Gateway integrations, S3 event trigger, or CORS settings are configured correctly.
